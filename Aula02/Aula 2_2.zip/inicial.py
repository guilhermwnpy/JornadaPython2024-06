import pandas as pd
import plotly.express as px

tabela = pd.read_csv('Aula02/cancelamentos.csv')

tabela = tabela.drop(columns="CustomerID") # exclui coluna CostumerID
tabela = tabela.dropna()


grafico = px.histogram(tabela, x="duracao_contrato", color="cancelou")
grafico.show()